% myu_exact.m

function ux = myu_exact(x)
    ux = sin(x)./(2+cos(x));
end
